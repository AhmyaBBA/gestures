//
//  GesturesTests.swift
//  GesturesTests
//
//  Created by Ahmya Rivera on 9/23/25.
//

import Testing
@testable import Gestures

struct GesturesTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
