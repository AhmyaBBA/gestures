//
//  GesturesApp.swift
//  Gestures
//
//  Created by Ahmya Rivera on 9/23/25.
//

import SwiftUI

@main
struct GesturesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
